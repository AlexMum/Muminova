use avto_salon;
select p.id_продажи, p.дата_продажи, k.фамилия, k.имя, a.название_модели, p.стоимость_продажи
from продажи p
inner join клиенты k on p.id_клиента = k.id_клиента
inner join авто a on p.id_авто = a.id_авто;

select k.фамилия, k.имя, p.id_продажи, p.дата_продажи, p.стоимость_продажи
from клиенты k
left join продажи p on k.id_клиента = p.id_клиента;

select s.фамилия, s.имя, s.должность, p.id_продажи, p.дата_продажи
from сотрудники s
left join продажи p on s.id_сотрудника = p.id_сотрудника;

select m.название_марки, a.название_модели, a.стоимость
from авто a
right join марка m on a.id_марки = m.id_марки;

select z.название_завода, z.страна, a.название_модели
from авто a
right join заводы z on a.id_завода = z.id_завода;

select название_модели, стоимость
from авто
where стоимость > (select avg(стоимость) from авто);

select фамилия, имя, номер_телефона
from клиенты
where id_клиента in (select id_клиента from продажи where стоимость_продажи > 2000000);

select название_модели, стоимость, год_выпуска
from авто
where id_авто not in (select id_авто from продажи where id_авто is not null);

select m.название_марки, средняя_цена
from марка m
join (select id_марки, avg(стоимость) as средняя_цена from авто group by id_марки) a
on m.id_марки = a.id_марки;

select s.фамилия, s.имя, количество_продаж
from сотрудники s
join (select id_сотрудника, count(*) as количество_продаж from продажи group by id_сотрудника) p
on s.id_сотрудника = p.id_сотрудника;

select фамилия, имя, номер_телефона,
       (select count(*) from продажи p where p.id_клиента = k.id_клиента) as количество_покупок
from клиенты k;

select название_модели, стоимость,
       (select count(*) from продажи p where p.id_авто = a.id_авто) as сколько_раз_продали
from авто a;

select название_модели, стоимость,
       row_number() over (order by стоимость desc) as место_по_цене
from авто;

select название_модели, стоимость,
       rank() over (order by стоимость desc) as ранг
from авто;

select a.название_модели, m.название_марки, a.стоимость,
       row_number() over (partition by a.id_марки order by a.стоимость desc) as номер_в_марке
from авто a
join марка m on a.id_марки = m.id_марки;

select название_модели, стоимость,
       lag(стоимость) over (order by стоимость) as предыдущая_цена
from авто;

select название_модели, стоимость,
       lead(стоимость) over (order by стоимость) as следующая_цена
from авто;

select m.название_марки, count(a.id_авто) as количество
from марка m
left join авто a on m.id_марки = a.id_марки
group by m.название_марки;

select s.фамилия, s.имя, sum(p.стоимость_продажи) as сумма_продаж
from сотрудники s
left join продажи p on s.id_сотрудника = p.id_сотрудника
group by s.id_сотрудника;

select год_выпуска, avg(стоимость) as средняя_цена
from авто
group by год_выпуска;

select m.название_марки, avg(a.стоимость) as средняя_цена
from марка m
join авто a on m.id_марки = a.id_марки
group by m.название_марки
having avg(a.стоимость) > 2000000;

select k.фамилия, k.имя, count(p.id_продажи) as количество_покупок
from клиенты k
join продажи p on k.id_клиента = p.id_клиента
group by k.id_клиента
having count(p.id_продажи) > 1;

select фамилия, имя, 'клиент' as кто from клиенты
union
select фамилия, имя, 'сотрудник' as кто from сотрудники;

select название_марки as название, 'марка' as тип from марка
union
select название_завода as название, 'завод' as tip from заводы;

select название_модели, стоимость,
       case
           when стоимость < 1500000 then 'бюджетный'
           when стоимость between 1500000 and 3000000 then 'средний'
           else 'премиум'
       end as категория
from авто;

select фамилия, имя,
       (select count(*) from продажи p where p.id_клиента = k.id_клиента) as покупок,
       case
           when (select count(*) from продажи p where p.id_клиента = k.id_клиента) = 0 then 'новый'
           when (select count(*) from продажи p where p.id_клиента = k.id_клиента) = 1 then 'редкий'
           else 'постоянный'
       end as тип_клиента
from клиенты k;

create view все_продажи as
select p.id_продажи, p.дата_продажи, p.стоимость_продажи, p.способ_оплаты,
       k.фамилия as фамилия_клиента, k.имя as имя_клиента, k.номер_телефона as номер_телефона_клиента,
       a.название_модели, m.название_марки, a.год_выпуска,
       s.фамилия as фамилия_сотрудника, s.должность
from продажи p
join клиенты k on p.id_клиента = k.id_клиента
join авто a on p.id_авто = a.id_авто
join марка m on a.id_марки = m.id_марки
join сотрудники s on p.id_сотрудника = s.id_сотрудника;

select * from все_продажи;

create view статистика_по_маркам as
select m.название_марки,
       count(a.id_авто) as всего_авто,
       avg(a.стоимость) as средняя_цена,
       min(a.стоимость) as минимальная_цена,
       max(a.стоимость) as максимальная_цена
from марка m
left join авто a on m.id_марки = a.id_марки
group by m.название_марки;

select * from статистика_по_маркам;

select дата_продажи, стоимость_продажи,
       sum(стоимость_продажи) over (order by дата_продажи) as накопленная_сумма
from продажи;

select m.название_марки, a.название_модели, a.стоимость,
       avg(a.стоимость) over (partition by a.id_марки) as среднее_по_марке
from авто a
join марка m on a.id_марки = m.id_марки;

select название_марки, название_модели, стоимость, среднее_по_марке,
       стоимость - среднее_по_марке as разница
from (
    select m.название_марки, a.название_модели, a.стоимость,
           avg(a.стоимость) over (partition by a.id_марки) as среднее_по_марке
    from авто a
    join марка m on a.id_марки = m.id_марки
) as t;

select k.фамилия, k.имя, p.дата_продажи, p.стоимость_продажи,
       row_number() over (partition by p.id_клиента order by p.дата_продажи) as номер_покупки
from продажи p
join клиенты k on p.id_клиента = k.id_клиента;

